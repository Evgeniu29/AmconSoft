package com.paad.amconsoft.userlist;

interface MyViewHolder {
}
