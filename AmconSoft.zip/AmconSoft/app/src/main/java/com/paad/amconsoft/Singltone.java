package com.paad.amconsoft;

import com.paad.amconsoft.model.User;

import java.util.ArrayList;
import java.util.List;

public class Singltone {
    public List<User> userList;
    private static  Singltone instance = new Singltone();
    private Singltone(){
         userList = new ArrayList<>();
    }

    public static  Singltone getInstance(){
        return instance;
    }

}
