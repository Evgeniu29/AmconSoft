package com.paad.amconsoft.userlist;

public interface OnUserClickListener {
    void onUserClick(int userID);
}
