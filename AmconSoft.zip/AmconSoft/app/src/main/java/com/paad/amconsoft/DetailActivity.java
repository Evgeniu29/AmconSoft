package com.paad.amconsoft;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;



public class DetailActivity extends AppCompatActivity {



    TextView  address;

    TextView phone;

    TextView website;

    TextView company;

    int result;

    private static final LatLng SYDNEY = new LatLng(-33.87365, 151.20689);



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.detail);




        address  = (TextView) findViewById(R.id._address);
        phone = (TextView) findViewById(R.id._phone);
        website = (TextView) findViewById(R.id._website);
        company = (TextView) findViewById(R.id._company);

        Intent intent = getIntent();

        result = intent.getIntExtra("position", 0);

        address.setText(Singltone.getInstance().userList.get(result).getAddress().getFullAddress());

        phone.setText(Singltone.getInstance().userList.get(result).getPhone());

        website.setText(Singltone.getInstance().userList.get(result).getWebsite());

        company.setText(Singltone.getInstance().userList.get(result).getCompany().getCompanyDescription());

    }



}
