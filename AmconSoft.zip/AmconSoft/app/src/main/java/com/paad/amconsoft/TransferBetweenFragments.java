package com.paad.amconsoft;

public interface TransferBetweenFragments {
    void goFromUserToPost(int userID);
}
