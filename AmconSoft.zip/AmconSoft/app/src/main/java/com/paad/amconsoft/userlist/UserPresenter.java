package com.paad.amconsoft.userlist;


import com.paad.amconsoft.Repository;
import com.paad.amconsoft.model.User;
import com.paad.amconsoft.remote.ApiResult;

import java.util.List;

public class UserPresenter implements UserContract.Presenter {

    private UserContract.View view;
    private Repository repository;

    public UserPresenter(UserContract.View view) {

        this.view = view;
        repository = new Repository();
    }

    @Override
    public void onLoadUser() {

        view.showProgressBar();

        repository.getUsers(new ApiResult<List<User>>() {
            @Override
            public void onSuccess(List<User> result) {
                view.hideProgressBar();
                view.showUserList(result);
            }

            @Override
            public void onFail() {
                view.showErrorMessage();
            }
        });
    }

}
